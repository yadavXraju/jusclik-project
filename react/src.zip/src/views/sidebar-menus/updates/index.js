


const Updates = () => {
  return (
   <>updates</>
  )
}

export default Updates;
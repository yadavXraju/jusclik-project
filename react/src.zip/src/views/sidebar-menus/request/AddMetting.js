import React from 'react'

const AddMetting = () => {
  return (
    <div>AddMetting</div>
  )
}

export default AddMetting
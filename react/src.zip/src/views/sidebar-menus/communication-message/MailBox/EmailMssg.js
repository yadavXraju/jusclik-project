import React from 'react'

const Message = () => {
  return (
    <div>EmailMssg</div>
  )
}

export default Message
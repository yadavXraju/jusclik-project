import React from 'react'
// import TotalGrowthBarChart from '../../dashboard/Default/TotalGrowthBarChart';
import AttendanceGraph from './AttendaceGraph'
import TotalGrowthBarChart from './TotalAttendanceBar'

const AttendanceChart = () => {
  return (
    <>
      {/* <TotalGrowthBarChart/> */}
      <AttendanceChart/>
      <TotalGrowthBarChart/>
    </>
  )
}

export default AttendanceGraph;

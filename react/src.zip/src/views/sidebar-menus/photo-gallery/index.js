import React from 'react'

const PhotoGallery = () => {
  return (
    <div>PhotoGallery</div>
  )
}

export default PhotoGallery
import React from 'react'

const OnlineClass = () => {
  return (
    <div>Online Class</div>
  )
}

export default OnlineClass
import React from 'react';
import { Grid, Paper, Typography, Button } from '@mui/material';
import { timetableRows } from 'views/sidebar-menus/timetable/Timetablelist';
import { gridSpacing } from 'store/constant';
import { Box } from '@mui/system';
import { useNavigate } from 'react-router';
import { getCurrentDay } from 'utils/dateUtils';

const TimeTableHome = () => {
  const periodsToShow = 4;
  const navigate = useNavigate();
  const currentDay = getCurrentDay();

  // Filter timetableRows based on the current day
  const filteredRows = timetableRows.filter(row => {
    return row.key === currentDay;
  });

  return (
    <Grid spacing={gridSpacing} sx={{ border: '1px solid #80808026', borderRadius: '8px' }}>
      <Grid item component={Paper} lg={12} md={12} sm={12} xs={12} sx={{ textAlign: 'right', p: 3, display: 'flex', flexDirection: 'column', gap: '48px' }}>
        <Typography variant='h2' sx={{ textAlign: 'left', color: '#99a1b7', borderBottom: '1px solid #80808040;', paddingBottom: '1px' }}>TimeTable</Typography>
        {filteredRows.slice(0, periodsToShow).map((row, index) => (
          <Grid container key={index} sx={{ textAlign: 'left', display: 'flex', borderBottom: '1px solid #80808040;', paddingBottom: '10px' }}>

            {/* The rest of your code remains the same */}
            <Grid item lg={4} md={4} sm={4} xs={4} sx={{ display: 'flex', gap: '16px' }}>
              <Typography variant='span' sx={{ color: '#99a1b7', fontWeight: '500' }}>Time:</Typography>
              <Typography variant='h5'>{row.time}</Typography>
            </Grid>

            {row.key !== null ? (
              <Grid item lg={4} md={4} sm={4} xs={4} sx={{ display: 'flex', gap: '16px' }}>
                <Typography variant='body2' sx={{ color: '#99a1b7', fontWeight: '500' }}>Period {row.key} :</Typography>
                <Typography variant='h5'>
                  <span>{row.sub}</span>
                </Typography>
              </Grid>
            ) : (
              <Grid item lg={4} md={4} sm={4} xs={4} sx={{ display: 'flex', gap: '16px' }}>
                <Typography variant='h5'>
                  <span>{row.sub}</span>
                </Typography>
              </Grid>
            )}

            {row.key !== null && (
              <Grid item lg={4} md={4} sm={4} xs={4} sx={{ display: 'flex', gap: '16px' }}>
                <Typography variant='body2' sx={{ color: '#99a1b7', fontWeight: '500' }}>Teacher:</Typography>
                <Typography variant='h5'>{row.teacher}</Typography>
              </Grid>
            )}
          </Grid>
        ))}

        <Box sx={{ pt: 3 }}>
          {periodsToShow < filteredRows.length && (
            <Button variant="contained" onClick={() => navigate('/timetable')}>
              View More
            </Button>
          )}
        </Box>
      </Grid>
    </Grid>
  );
}

export default TimeTableHome;

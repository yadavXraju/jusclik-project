
import React from 'react'

const OnlineAssessment = () => {
  return (
    <div>Online Assessment</div>
  )
}

export default OnlineAssessment
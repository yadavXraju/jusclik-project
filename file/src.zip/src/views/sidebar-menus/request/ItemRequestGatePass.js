import React from 'react'

const ItemRequestGatePass = () => {
  return (
    <div>Item Request Gate Pass</div>
  )
}

export default ItemRequestGatePass
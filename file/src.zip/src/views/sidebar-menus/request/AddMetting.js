import React from 'react'

const AddMetting = () => {
  return (
    <div>Add Metting</div>
  )
}

export default AddMetting
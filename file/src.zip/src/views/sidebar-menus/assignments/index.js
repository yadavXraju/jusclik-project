import React from 'react';

const Assignments = () => {
  return (
    <>
    Assignments
    </>
  );
}

export default Assignments;

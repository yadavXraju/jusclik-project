import React from 'react'
import TotalGrowthBarChart from '../../dashboard/Default/TotalGrowthBarChart';

const AttendanceChart = () => {
  return (
    <>
      <TotalGrowthBarChart/>
    </>
  )
}

export default AttendanceChart;

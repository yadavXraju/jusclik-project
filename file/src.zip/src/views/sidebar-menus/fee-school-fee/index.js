import React from 'react'

const SchoolFee = () => {
  return (
    <div>fee</div>
  )
}

export default SchoolFee
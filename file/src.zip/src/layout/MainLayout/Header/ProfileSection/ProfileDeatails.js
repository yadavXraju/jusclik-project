import User1 from 'assets/images/users/user-round.svg';

export const studentProfileDetails = {
  StudentImage: User1,
  StudentName : 'Abhishek Negi',
  Class : 'V A',
  AdminNo :'(Adm No : D00158)',
};

// absent and present details
export const present = '63.3%';
export const absent = ' 36.7%';


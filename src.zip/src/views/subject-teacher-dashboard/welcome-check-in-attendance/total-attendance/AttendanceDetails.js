// export const TotalAttendanceDeatails = {
//     attendancePercentage : '85%',
// }


export const TotalAttendanceDeatails  = {
    id :1,
    counterValue : '90%'  ,
    counterTitle : 'TOTAL ATTENDANCE',
}
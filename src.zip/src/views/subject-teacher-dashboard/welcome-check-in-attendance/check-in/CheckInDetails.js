// export const CheckInAndCheckOutData = [
//     {
//         id: 1,
//         date: '02-Feb-2024',
//         details: {
//             checkIn : ' 09:30 AM',
//             checkOut : ' 09:21 AM'
//         }
        
//     }
// ]


export const CheckInAndCheckOutData  = {
    id :1,
    counterValue : '09:30 AM'  ,
    counterTitle : 'CHECK IN TIME',
}

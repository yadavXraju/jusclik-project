export const TeacherTimeTableDetails = [
    {
        id:1,
        period : 'I',
        class : 'V A',
        subject : 'English',
        Time : '9:00am-9:45'
    },

    {
        id:2,
        period : 'II',
        class : 'V B',
        subject : 'Math',
        Time : '9:45am-10:30'
    },

    
    {
        id:3,
        period : 'III',
        class : 'IV A',
        subject : 'Hindi',
        Time : '10:30am-11:15'
    },

        
    {
        id:4,
        period : 'IV',
        class : 'V A',
        subject : 'Science',
        Time : '11:15am-12:00'
    },

    {
        id:5,
        period : 'break',
        // class : '',
        // subject : 'Science',
        Time : '12:00pm-12:45'
    },

    {
        id:6,
        period : 'V',
        class : 'V C',
        subject : 'Social Science',
        Time : '12:45pm-1:30'
    },

    {
        id:7,
        period : 'VI',
        class : '--',
        subject : '--',
        Time : '1:30pm-2:15'
    },

    {
        id:8,
        period : 'VII',
        class : 'V A',
        subject : 'Chemistry',
        Time : '2:15pm-3:00'
    },

    {
        id:9,
        period : 'VIII',
        class : '--',
        subject : '--',
        Time : '3:00pm-3:45'
    },
]
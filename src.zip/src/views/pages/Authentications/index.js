import Logins from '../authentication/Login';

const Authentications = () => {
  return (
    <Logins/>
  )
}

export default Authentications;
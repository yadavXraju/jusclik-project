// export const TotalAttendanceDeatails = {
//     attendancePercentage : '92%',
// }



export const TotalAttendanceDeatails  = {
    id :1,
    counterValue : '92%'  ,
    counterTitle : 'TOTAL ATTENDANCE',
}
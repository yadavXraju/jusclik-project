import React from "react";
import { CheckInAndCheckOutData } from "./CheckInDeatils";
import Counter1 from "views/common-section/Counter1";

const ClassTeacherCheckIn = () => {
  return (
    <>
      <Counter1 Counter1Data={CheckInAndCheckOutData} />
    </>
  )
}

export default ClassTeacherCheckIn

export const StudentStrengthList = [

     {
        id:1,
        totalStudent : 55,
        boys : 30,
        girls: 25,

     }
]
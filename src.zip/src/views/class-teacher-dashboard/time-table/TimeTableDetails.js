export const TeacherTimeTableDetails = [
    {
        id:1,
        period : 'I',
        class : 'V A',
        subject : 'Hindi',
        Time : '9:00am-9:45'
    },

    {
        id:2,
        period : 'II',
        class : 'V B',
        subject : 'English',
        Time : '9:45am-10:30'
    },

    
    {
        id:3,
        period : 'III',
        class : 'IV A',
        subject : 'Math',
        Time : '10:30am-11:15'
    },

        
    {
        id:4,
        period : 'IV',
        class : 'V A',
        subject : 'Science',
        Time : '11:15am-12:00'
    },
]
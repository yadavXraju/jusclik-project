import AvatarImg from '../../../assets/images/avatar.png'

export const StudentLeaveData = [
  {
    id:0,
    name:  'Suraj1',
    class : ' V A',
    image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
    date : '06-02-2024'
   },

  {
   id:1,
   name:  'Suraj',
   class : ' V A',
   image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
   date : '06-02-2024'
  },

  {
    id:2,
    name:  'Vikash',
    class : ' V A',
    image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
    date : '06-02-2024'
   },


   {
    id:3,
    name:  'Rubi',
    class : ' V A',
    image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
    date : '06-02-2024'
   },

   {
    id:4,
    name:  'Suraj',
    class : ' V A',
    image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
    date : '06-02-2024'
   },
 
   {
     id:5,
     name:  'Vikash',
     class : ' V A',
     image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
     date : '06-02-2024'
    },
 
 
    {
     id:6,
     name:  'Rubi',
     class : ' V A',
     image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
     date : '06-02-2024'
    },


    {
      id:7,
      name:  'Suraj',
      class : ' V A',
      image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
      date : '04-02-2024'
     },
   
     {
       id:8,
       name:  'Vikash',
       class : ' V A',
       image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
       date : '04-02-2024'
      },
   
   
      {
       id:9,
       name:  'Rubi',
       class : ' V A',
       image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
       date : '06-02-2024'
      },


      {
        id:10,
        name:  'Suraj',
        class : ' V A',
        image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
        date : '04-02-2024'
       },
     
       {
         id:11,
         name:  'Vikash',
         class : ' V A',
         image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
         date : '06-02-2024'
        },
     
     
        {
         id:12,
         name:  'Rubi',
         class : ' V A',
         image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
         date : '04-02-2024'
        },

        {
          id:13,
          name:  'Suraj',
          class : ' V A',
          image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
          date : '04-02-2024'
         },
       
         {
           id:14,
           name:  'Vikash',
           class : ' V A',
           image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
           date : '06-02-2024'
          },
       
       
          {
           id:15,
           name:  'Rubi',
           class : ' V A',
           image: <img src={AvatarImg} alt="avatar" style={{ width: '70px', height: '70px', borderRadius: '50%' }} />,
           date : '04-02-2024'
          },

]

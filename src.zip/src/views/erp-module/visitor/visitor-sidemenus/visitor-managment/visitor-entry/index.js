import React from 'react'


const VisitorEntry = () => {
  return (
    <>
           <h1>visitor</h1>
    </>
  )
}

export default VisitorEntry
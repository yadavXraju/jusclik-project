import React from 'react'

const ScheduledVisit = () => {
  return (
    <div> Scheduled Visit </div>
  )
}

export default ScheduledVisit
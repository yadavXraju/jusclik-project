import React from 'react'

const SmsDeliveryReport = () => {
  return (
    <div>Sms Delivery 12</div>
  )
}

export default SmsDeliveryReport
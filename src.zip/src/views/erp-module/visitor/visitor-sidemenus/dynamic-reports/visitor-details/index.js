import React from 'react'

const VisitorDetails = () => {
  return (
    <div>Visitor Details</div>
  )
}

export default VisitorDetails
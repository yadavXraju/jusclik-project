export const TotalVisitorData = {
        id :1,
        counterValue : '34'  ,
        counterTitle : 'Total VISITORS',
    }

export const TodayVisitorData = {
        id :1,
        counterValue : '0'  ,
        counterTitle : 'VISITORS TODAY',
    }

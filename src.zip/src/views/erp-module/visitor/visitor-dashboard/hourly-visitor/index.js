import React from 'react'

const HourlyVisior = () => {
  return (
    <div>index</div>
  )
}

export default HourlyVisior
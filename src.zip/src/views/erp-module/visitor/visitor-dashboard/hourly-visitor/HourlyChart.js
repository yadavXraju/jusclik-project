import React from 'react'

const HourlyChart = () => {
  return (
    <>HourlyChart</>
  )
}

export default HourlyChart
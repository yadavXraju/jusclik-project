import CalendarMonthTwoToneIcon from '@mui/icons-material/CalendarMonthTwoTone';

export const UpdatesData = [
    {id:1 , title : 'St. Xavier School Gurugram' , description:'Your content here A single core framework and long term tool built on top of Bootstrap 5 for delivering limitless highly customized projects Your content here A single core framework and long term tool built on top of Bootstrap 5 for delivering limitless highly customized projects',  month:'Jan',date:'14', year:'2024', day :'Sun' , icon: CalendarMonthTwoToneIcon } ,


    {id:2 , title : 'St. Xavier School Gurugram' , description:'Your content here A single core framework and long term tool built on top of Bootstrap 5 for delivering limitless highly customized projects Your content here A single core framework and long term tool built on top of Bootstrap 5 for delivering limitless highly customized projects', date:'15', month:'Jan', year:'2024', day :'Mon' , icon: CalendarMonthTwoToneIcon},


    {id:3 , title : 'St. Xavier School Gurugram' , description:'Your content here A single core framework and long term tool built on top of Bootstrap 5 for delivering limitless highly customized projects',date:'16', month:'Jan', year:'2024', day :'Tue' , icon: CalendarMonthTwoToneIcon},


    {id:4 , title : 'St. Xavier School Gurugram' , description:'Your content here A single core framework and long term tool built on top of Bootstrap 5 for delivering limitless highly customized projects', date:'17', month:'Jan', year:'2024', day :'Wed' , icon: CalendarMonthTwoToneIcon},



    {id:5 , title : 'St. Xavier School Gurugram' , description:'Your content here A single core framework and long term tool built on top of Bootstrap 5 for delivering limitless highly customized projects', date:'18', month:'Jan', year:'2024', day :'Thur' , icon: CalendarMonthTwoToneIcon}


];
import React from 'react'

const UploadPhotoGallery = () => {
  return (
    <div>
        <h1>Upload Photo gallery </h1>
    </div>
  )
}

export default UploadPhotoGallery
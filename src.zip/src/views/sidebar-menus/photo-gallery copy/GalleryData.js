export const coverData = [
    {
      image: '/images/front-view-smiley-woman-with-fireworks.jpg',
      title: 'Diwali Celebration',
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.',
      date: "2-jan-2024"
    },
    // Add more objects for additional gallery items if needed
    {
      image: '/images/front-view-smiley-woman-with-fireworks.jpg',
      title: 'Diwali Celebration',
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.',
      date: "23-jan-2024"
    },
    {
      image: '/images/front-view-smiley-woman-with-fireworks.jpg',
      title: 'Diwali Celebration',
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quam velit, vulputate eu pharetra nec, mattis ac neque.',
      date: "22-jan-2024"
    },
  ];




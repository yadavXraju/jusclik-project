// import <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/> from './link.png'
import AttachmentOutlinedIcon from '@mui/icons-material/AttachmentOutlined';
export const LinkData = [
    {
        id:1,
        linkText : 'The Wisdom Tree School',
        link : 'https://www.thewisdomtree.co/',
        thumbnailUrl : <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/>,
    },
    {
        id:2,
        linkText : 'The Wisdom Tree School',
        link : 'https://www.thewisdomtree.co/',
        thumbnailUrl : <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/>,
    },
    {
        id:3,
        linkText : 'The Wisdom Tree School',
        link : 'https://www.thewisdomtree.co/',
        thumbnailUrl : <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/>,
    },
    {
        id:4,
        linkText : 'The Wisdom Tree School',
        link : 'https://www.thewisdomtree.co/',
        thumbnailUrl : <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/>,
    },
    {
        id:5,
        linkText : 'The Wisdom Tree School',
        link : 'https://www.thewisdomtree.co/',
        thumbnailUrl : <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/>,
    },
    {
        id:6,
        linkText : 'The Wisdom Tree School',
        link : 'https://www.thewisdomtree.co/',
        thumbnailUrl : <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/>,
    },
    {
        id:7,
        linkText : 'The Wisdom Tree School',
        link : 'https://www.thewisdomtree.co/',
        thumbnailUrl : <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/>,
    },
    {
        id:8,
        linkText : 'The Wisdom Tree School',
        link : 'https://www.thewisdomtree.co/',
        thumbnailUrl : <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/>,
    },

    {
        id:9,
        linkText : 'The Wisdom Tree School',
        link : 'https://www.thewisdomtree.co/',
        thumbnailUrl : <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/>,
    },
    {
        id:10,
        linkText : 'The Wisdom Tree School',
        link : 'https://www.thewisdomtree.co/',
        thumbnailUrl : <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/>,
    },
    {
        id:11,
        linkText : 'The Wisdom Tree School',
        link : 'https://www.thewisdomtree.co/',
        thumbnailUrl : <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/>,
    },
    {
        id:12,
        linkText : 'The Wisdom Tree School',
        link : 'https://www.thewisdomtree.co/',
        thumbnailUrl : <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/>,
    },
    {
        id:13,
        linkText : 'The Wisdom Tree School',
        link : 'https://www.thewisdomtree.co/',
        thumbnailUrl : <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/>,
    },
    {
        id:14,
        linkText : 'The Wisdom Tree School',
        link : 'https://www.thewisdomtree.co/',
        thumbnailUrl : <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/>,
    },

    {
        id:15,
        linkText : 'The Wisdom Tree School',
        link : 'https://www.thewisdomtree.co/',
        thumbnailUrl : <AttachmentOutlinedIcon sx={{width:'4rem' , height:'4rem' , paddingLeft:'18px' , color : '#5a4f4f'}}/>,
    },

]
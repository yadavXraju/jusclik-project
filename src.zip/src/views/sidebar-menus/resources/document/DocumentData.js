
import pdf from './pdfIcon.png';
export const documentData = [
    {
        id: 1,
        url:'https://www.thewisdomtree.co/downloads?download=the-jungle-book#54',
        title:' The Jungle Book',
        subtitle : ' Rudyard Kipling',
        thumbnailUrl: pdf,
         postDate:'20-Jan-2029',
    },

    {
        id: 2,
        url:'https://www.thewisdomtree.co/downloads?download=the-jungle-book#54',
        title:' The Jungle Book',
        subtitle : ' Rudyard Kipling',
        thumbnailUrl: pdf,
         postDate:'20-Jan-2022',
    },

    {
        id: 3,
        url:'https://www.thewisdomtree.co/downloads?download=the-jungle-book#54',
        title:' The Jungle Book',
        subtitle : ' Rudyard Kipling',
        thumbnailUrl: pdf,
        postDate:'20-Feb-2022',
    },
    {
        id: 4,
        url:'https://www.thewisdomtree.co/downloads?download=the-jungle-book#54',
        title:' The Jungle Book',
        subtitle : ' Rudyard Kipling',
        thumbnailUrl: pdf,
         postDate:'20-Jan-2027',
    },

    {
        id: 5,
        url:'https://www.thewisdomtree.co/downloads?download=the-jungle-book#54',
        title:' The Jungle Book',
        subtitle : ' Rudyard Kipling',
        thumbnailUrl: pdf,
         postDate:'20-July-2021',
    },

    {
        id: 6,
        url:'https://www.thewisdomtree.co/downloads?download=the-jungle-book#54',
        title:' The Jungle Book',
        subtitle : ' Rudyard Kipling',
        thumbnailUrl: pdf,
         postDate:'20-Feb-2026',
    },

    {
        id: 7,
        url:'https://www.thewisdomtree.co/downloads?download=the-jungle-book#54',
        title:' The Jungle Book',
        subtitle : ' Rudyard Kipling',
        thumbnailUrl: pdf,
         postDate:'20-Jan-2023',
    },

    {
        id: 8,
        url:'https://www.thewisdomtree.co/downloads?download=the-jungle-book#54',
        title:' The Jungle Book',
        subtitle : ' Rudyard Kipling',
        thumbnailUrl: pdf,
         postDate:'20-Jan-2025',
    },

    {
        id: 9,
        url:'https://www.thewisdomtree.co/downloads?download=the-jungle-book#54',
        title:' The Jungle Book',
        subtitle : ' Rudyard Kipling',
        thumbnailUrl: pdf,
         postDate:'20-May-2022',
    },
    {
        id: 10,
        url:'https://www.thewisdomtree.co/downloads?download=the-jungle-book#54',
        title:' The Jungle Book',
        subtitle : ' Rudyard Kipling',
        thumbnailUrl: pdf,
         postDate:'20-Jan-2027',
    },

    {
        id: 11,
        url:'https://www.thewisdomtree.co/downloads?download=the-jungle-book#54',
        title:' The Jungle Book',
        subtitle : ' Rudyard Kipling',
        thumbnailUrl: pdf,
         postDate:'20-Aug-2029',
    },

    {
        id: 12,
        url:'https://www.thewisdomtree.co/downloads?download=the-jungle-book#54',
        title:' The Jungle Book',
        subtitle : ' Rudyard Kipling',
        thumbnailUrl: pdf,
         postDate:'20-Feb-2029',
    },


]
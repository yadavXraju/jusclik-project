export const ImageData = [
    {
       id:1,
       src:'https://cloud9.shauryasoft.com/media/wcp-2312041738-0233659109-3.png',
       title:'Wisdom Tree',
       postDate:'20-Jan-2024',
    },
    {
        id:2,
       src:'https://cloud9.shauryasoft.com/media/wcp-2312041738-1141130420-1.png',
        title:'Wisdom Tree',
        postDate:'20-Jan-2023',
     },
     {
        id:3,
       src:'https://cloud9.shauryasoft.com/media/wcp-2312041738-0233659109-4.png',
        title:'Wisdom Tree',
        postDate:'10-Jan-2024',
     },
     {
      id:4,
      src:'https://cloud9.shauryasoft.com/media/wcp-2312041738-0233659109-3.png',
      title:'Wisdom Tree',
      postDate:'20-Feb-2024',
   },
   {
       id:5,
      src:'https://cloud9.shauryasoft.com/media/wcp-2312041738-1141130420-1.png',
       title:'Wisdom Tree',
       postDate:'20-Jun-2024',
    },
    {
       id:6,
      src:'https://cloud9.shauryasoft.com/media/wcp-2312041738-0233659109-4.png',
       title:'Wisdom Tree',
       postDate:'20-Dec-2024',
    },
     {
        id:7,
       src:'https://cloud9.shauryasoft.com/media/wcp-2312041738-0233659109-3.png',
        title:'Wisdom Tree',
        postDate:'20-Jan-2022',
     },
     {
        id:8,
       src:'https://cloud9.shauryasoft.com/media/wcp-2312041738-0233659109-3.png',
        title:'Wisdom Tree',
        postDate:'20-Jan-2021',
     },
]
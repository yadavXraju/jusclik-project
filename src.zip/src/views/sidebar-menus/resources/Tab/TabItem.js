// you can add more label in the tab here 

export const TabItem = [
    {
        id:1,
        label:'Video',
        value: '1'
    },

    {
        id:2,
        label:'Images',
        value: '2'
    },

    {
        id:3,
        label:'Documents',
        value: '3'
    },

    {
        id:4,
        label:'Links',
        value: '4'
    },
]


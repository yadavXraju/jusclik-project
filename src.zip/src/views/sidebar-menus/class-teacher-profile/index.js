import React from 'react'

const ClassTeacherProfile = () => {
  return (
    <div>ClassTeacherProfile</div>
  )
}

export default ClassTeacherProfile
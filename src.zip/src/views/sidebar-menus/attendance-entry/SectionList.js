export const SectionList = [
    { id: '1', value:'A', section:'A' },
    { id: '2', value:'B', section:'B' },
    { id: '3', value:'C', section:'C' },
    // Add more sections as needed
  ];
  
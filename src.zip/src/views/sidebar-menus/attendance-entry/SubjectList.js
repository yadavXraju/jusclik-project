// export const SubjectList = [
//     {
//         id: '1',
//         class: 'Pre-Nursery',
//         subjects: ['English', 'Mathematics', 'Art and Craft'],
//     },
//     {
//         id: '2',
//         class: 'Nursery',
//         subjects: ['English', 'Mathematics', 'Drawing', 'Rhymes'],
//     },
//     {
//         id: '3',
//         class: 'Kindergarten',
//         subjects: ['English', 'Mathematics', 'Environmental Science', 'Music'],
//     },
//     {
//         id: '4',
//         class: 'Class I',
//         subjects: ['English', 'Mathematics', 'Science', 'Social Studies'],
//     },
//     {
//         id: '5',
//         class: 'Class II',
//         subjects: ['English', 'Mathematics', 'EVS', 'Computer Science'],
//     },
//     {
//         id: '6',
//         class: 'Class III',
//         subjects: ['English', 'Mathematics', 'Science', 'Social Studies'],
//     },
//     {
//         id: '7',
//         class: 'Class IV',
//         subjects: ['English', 'Mathematics', 'EVS', 'General Knowledge'],
//     },
//     {
//         id: '8',
//         class: 'Class V',
//         subjects: ['English', 'Mathematics', 'Science', 'Social Studies'],
//     },
//     {
//         id: '9',
//         class: 'Class VI',
//         subjects: ['English', 'Mathematics', 'Science', 'Social Studies'],
//     },
//     {
//         id: '10',
//         class: 'Class VII',
//         subjects: ['English', 'Mathematics', 'Science', 'Social Studies'],
//     },
//     {
//         id: '11',
//         class: 'Class VIII',
//         subjects: ['English', 'Mathematics', 'Science', 'Social Studies'],
//     },
//     {
//         id: '12',
//         class: 'Class IX',
//         subjects: ['English', 'Mathematics', 'Science', 'Social Studies'],
//     },
//     {
//         id: '13',
//         class: 'Class X',
//         subjects: ['English', 'Mathematics', 'Science', 'Social Studies'],
//     },
//     {
//         id: '14',
//         class: 'Class XI',
//         subjects: ['Physics', 'Chemistry', 'Biology', 'Mathematics'],
//     },
//     {
//         id: '15',
//         class: 'Class XII',
//         subjects: ['Physics', 'Chemistry', 'Biology', 'Mathematics'],
//     },
// ];

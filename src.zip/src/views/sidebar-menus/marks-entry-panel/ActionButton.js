import React from 'react'
import { Button } from '@mui/material'
function ActionButton() {
  return (
             <div>
            <Button  variant="outlined" size="small"  sx={{ padding: '10px', margin: '0 0 6px 8px', width: '100px' }}>
                Actions
            </Button>
           
        </div>
  )
}

export default ActionButton

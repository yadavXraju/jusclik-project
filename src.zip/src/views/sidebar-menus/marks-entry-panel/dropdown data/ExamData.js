const EXAM=[{
    value:"1",
    label:"UT-1"
},
{
    value:"2",
    label:"TERM 1"
},
{
    value:"3",
    label:"UT-2"
},
{
    value:"5",
    label:"TERM 2"
}
]

export {EXAM}
const subject = [
  {
    id: 0,
    value: "0",
    label: "All",

  },
    {
      id: 1,
      value: "1",
      label: "English",
      tm:20
    },
    {
      id: 2,
      value: "2",
      label: "Hindi",
      tm:20
    },
    {
      id: 3,
      value: "3",
      label: "Punjabi",
      tm:20
    },
    {
      id: 4,
      value: "5",
      label: "Science",
      tm:20
    },
    {
      id: 5,
      value: "6",
      label: "Social Studies",
      tm:20
    },
    {
      id: 6,
      value: "7",
      label: "Science",
      tm:20
    },
    {
      id: 7,
      value: "8",
      label: "History",
      tm:20
    },
    {
      id: 8,
      value: "9",
      label: "Physics",
      tm:20
    },
    // {
    //   id: 9,
    //   value: "10",
    //   label: "Geography",
    //   tm:20
    // },
    // {
    //   id: 10,
    //   value: "11",
    //   label: "Economics",
    //   tm:20
    // },
    // {
    //   id: 11,
    //   value: "12",
    //   label: "Civics",
    //   tm:20
    // },
    // {
    //   id: 12,
    //   value: "13",
    //   label: "E.V.S",
    //   tm:20
    // },
    // {
    //   id: 13,
    //   value: "14",
    //   label: "Math",
    //   tm:20
    // },
    // {
    //   id: 14,
    //   value: "15",
    //   label: "Chemistry",
    //   tm:20
    // },
    // {
    //   id: 15,
    //   value: "16",
    //   label: "Bio",
    //   tm:20
    // },
    // {
    //   id: 16,
    //   value: "17",
    //   label: "Arts",
    //   tm:20
    // },
    // {
    //   id: 17,
    //   value: "18",
    //   label: "Arts",
    //   tm:20
    // }
  ];
  
  export { subject };
  

  const subject2 = [
    {
      id: 0,
      value: "0",
      label: "All",
  
    },
      {
        id: 1,
        value: "1",
        label: "English",
        tm:50
      },
      {
        id: 2,
        value: "2",
        label: "Hindi",
        tm:50
      },
      {
        id: 3,
        value: "3",
        label: "Punjabi",
        tm:50
      },
      {
        id: 4,
        value: "5",
        label: "Science",
        tm:50
      },
      {
        id: 5,
        value: "6",
        label: "Social Studies",
        tm:50
      },
      {
        id: 6,
        value: "7",
        label: "Science",
        tm:50
      },
      {
        id: 7,
        value: "8",
        label: "History",
        tm:50
      },
      {
        id: 8,
        value: "9",
        label: "Physics",
        tm:50
      }
    ];
    
    export { subject2 };
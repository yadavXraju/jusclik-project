const ClassData = [
    {
      value: '1',
      label: 'I',
    },
    {
      value: '2',
      label: 'II',
    },
    {
      value: '3',
      label: 'III',
    },
    {
      value: '4',
      label: 'IV',
    },
   
  ];

  export { ClassData };
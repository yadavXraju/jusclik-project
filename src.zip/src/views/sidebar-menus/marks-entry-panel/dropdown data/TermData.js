const Term=[
    {
        value:'1',
        label:'I'
    },
    {
        value:'2',
        label:'II'
    }
]

export {Term};

import React from 'react'
import Request from './Request'

const ItemRequestGatePass = () => {
  return (
    <div>
   <Request/>
      </div>
  )
}

export default ItemRequestGatePass
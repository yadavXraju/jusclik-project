const { Textarea } = require("@mui/joy");
const { Typography } = require("@mui/material");

<Grid>
    <Grid>
        <Typography>Information as per record</Typography>
        <TextField  id="outlined-select-option"
            label="Name"
            fullWidth/>
    </Grid>
</Grid>

import React from 'react'

const RemarkEntry = () => {
  return (
    <div>
      
    </div>
  )
}

export default RemarkEntry

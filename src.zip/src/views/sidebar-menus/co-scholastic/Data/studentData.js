export const StudentData=[
  { id:0,name: 'All'},
  { id:1,name: 'Sangeeta', admissionNo: '1323' },
{ id:2,name: 'Anjali', admissionNo: '123' },
{ id:3,name: 'Aman', admissionNo: '2434', },
{ id:4,name: 'Laksh', admissionNo: '2634' },
{ id:5,name: 'Archita', admissionNo: '2634'},
{ id:6,name: 'Dexter', admissionNo: '2634' },
{ id:7,name: 'Suraj', admissionNo: '2634' },
{ id:8,name: 'Mixter', admissionNo: '2634' },
{ id:9,name: 'Sangeeta', admissionNo: '1323' },
{ id:10,name: 'Anjali', admissionNo: '123' },
{ id:11,name: 'Aman', admissionNo: '2434' },
{ id:11,name: 'Aman', admissionNo: '2434' },
{ id:12,name: 'Laksh', admissionNo: '2634' },
{ id:13,name: 'Archita', admissionNo: '2634' },
{ id:14,name: 'Dexter', admissionNo: '2634' },
{ id:15,name: 'Suraj', admissionNo: '2634' },
{ id:16,name: 'Mixter', admissionNo: '2634' },
]



export const StudentData2=[
  { id:0,name: 'All',value:0},
{ id:1,name: 'Sangeeta1', admissionNo: '1323' },
{ id:2,name: 'Anjali1', admissionNo: '123' },
{id:3, name: 'Aman1', admissionNo: '2434' },
{id:4, name: 'Laksh1', admissionNo: '2634' },
{id:5, name: 'Archita1', admissionNo: '2634' },
{id:6, name: 'Dexter1', admissionNo: '2634' },
{id:7, name: 'Suraj1', admissionNo: '2634' },
{id:8, name: 'Mixter1', admissionNo: '2634' },
]


export const StudentData3=[
  { id:0,name: 'All'},
{  id:1,name: 'Sangeeta11', admissionNo: '1323' },
{  id:2,name: 'Anjali11', admissionNo: '123' },
{  id:3,name: 'Aman11', admissionNo: '2434' },
{  id:4,name: 'Laksh11', admissionNo: '2634' },
{  id:5,name: 'Archita11', admissionNo: '2634' },
{  id:6,name: 'Dexter11', admissionNo: '2634' },
{ id:7, name: 'Suraj11', admissionNo: '2634' },
{  id:8,name: 'Mixter11', admissionNo: '2634' },
]

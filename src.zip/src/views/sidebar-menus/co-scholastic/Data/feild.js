export const  FeildData=[{
id:1,
name:"Work Education"
},
{
id:2,
name:"Discipline"
},
{
id:3,
name:"Art Eductation"
},
{
id:4,
name:"Health & Physical Education"
},
]


import React from 'react'

const Setting = () => {
  return (
    <div>setting</div>
  )
}

export default Setting
import React from 'react'

const TeacherInbox = () => {
  return (
    <div>Teacher Inbox</div>
  )
}

export default TeacherInbox
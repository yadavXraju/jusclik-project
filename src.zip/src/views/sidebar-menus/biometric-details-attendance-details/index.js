import React from 'react'

const BiometricDetailsOrAttendanceDetails = () => {
  return (
    <div>bio</div>
  )
}

export default BiometricDetailsOrAttendanceDetails
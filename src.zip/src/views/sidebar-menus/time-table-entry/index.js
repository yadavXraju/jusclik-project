import React from 'react'

const TimeTableEntry = () => {
  return (
    <div>Time Table Entry</div>
  )
}

export default TimeTableEntry
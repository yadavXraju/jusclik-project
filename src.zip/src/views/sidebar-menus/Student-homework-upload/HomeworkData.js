const HomeworkData = [
    {
      subject: 'Maths 101|Unit-2:Linear Programming',
      classSection: 'V-A',
      homeworkDate: '01/05/2024',
      dueDate: '02/05/2024',
      submissionRate: '69%',
      status: 'Grade in progress'
    },
    {
      subject: 'Maths 102|Unit-2:Add and Subtract',
      classSection: 'V-A',
      homeworkDate: '07-01-2024',
      dueDate: '07-02-2024',
      submissionRate: '95%',
      status: 'Ready for grading'
    },
    {
      subject: 'Maths 103|Unit-2:Motion and Force',
      classSection: 'V-A',
      homeworkDate: '12-01-2024',
      dueDate: '12-02-2024',
      submissionRate: '100%',
      status: 'Graded successfully'
    }
    // Add more homework data objects as needed
  ];
export default HomeworkData;

import React from 'react';
import Homework from './HomeWork';
import HomeworkProgressChart from './HomeworkProgress';

const StudentHomeworkUpload = () => {
  return (
    <>
    <HomeworkProgressChart/>
  <Homework/>
  </>
  )
}

export default StudentHomeworkUpload;
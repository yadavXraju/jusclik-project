import React from 'react'
import StudentData from './StudentData'
const index = () => {
  return (
    <div>
      <StudentData/>
    </div>
  )
}

export default index
const studentDataList = [
    {
      srNo: 1,admNo: 'D00158', admDate: '01/05/2024', studentName: 'Aarav Joshi', class: 'V-A', gender: 'Male', rollNo: 1, category: 'Staff Ward', birthDate: '05/02/2020', mobile: '0123456789', phone: '0123456789',email: 'support@shauryasoft.com',address: 'Delhi',fatherName: 'Deepak Joshi',fatherMobile: '9999999999',fatherEmail: 'Father@gmail.com',motherName: 'Mrs Joshi',motherMobile: '9897969594',motherEmail: 'Mother@gmail.com',bloodGroup: 'O+',house: 'Red house',religion: 'Hinduism',pickRoute: 'Station 1',dropRoute: 'Station 2'
    },
    {
        srNo: 2,admNo: 'D00158', admDate: '01/05/2024', studentName: 'Aarav Joshi', class: 'V-A', gender: 'Male', rollNo: 1, category: 'Staff Ward', birthDate: '05/02/2020', mobile: '0123456789', phone: '0123456789',email: 'support@shauryasoft.com',address: 'Delhi',fatherName: 'Deepak Joshi',fatherMobile: '9999999999',fatherEmail: 'Father@gmail.com',motherName: 'Mrs Joshi',motherMobile: '9897969594',motherEmail: 'Mother@gmail.com',bloodGroup: 'O+',house: 'Red house',religion: 'Hinduism',pickRoute: 'Station 1',dropRoute: 'Station 2'
      },
      {
        srNo: 3,admNo: 'D00158', admDate: '01/05/2024', studentName: 'Aarav Joshi', class: 'V-A', gender: 'Male', rollNo: 1, category: 'Staff Ward', birthDate: '05/02/2020', mobile: '0123456789', phone: '0123456789',email: 'support@shauryasoft.com',address: 'Delhi',fatherName: 'Deepak Joshi',fatherMobile: '9999999999',fatherEmail: 'Father@gmail.com',motherName: 'Mrs Joshi',motherMobile: '9897969594',motherEmail: 'Mother@gmail.com',bloodGroup: 'O+',house: 'Red house',religion: 'Hinduism',pickRoute: 'Station 1',dropRoute: 'Station 2'
      },
      {
        srNo: 4,admNo: 'D00158', admDate: '01/05/2024', studentName: 'Aarav Joshi', class: 'V-A', gender: 'Male', rollNo: 1, category: 'Staff Ward', birthDate: '05/02/2020', mobile: '0123456789', phone: '0123456789',email: 'support@shauryasoft.com',address: 'Delhi',fatherName: 'Deepak Joshi',fatherMobile: '9999999999',fatherEmail: 'Father@gmail.com',motherName: 'Mrs Joshi',motherMobile: '9897969594',motherEmail: 'Mother@gmail.com',bloodGroup: 'O+',house: 'Red house',religion: 'Hinduism',pickRoute: 'Station 1',dropRoute: 'Station 2'
      }, 
       {
        srNo: 5,admNo: 'D00158', admDate: '01/05/2024', studentName: 'Aarav Joshi', class: 'V-A', gender: 'Male', rollNo: 1, category: 'Staff Ward', birthDate: '05/02/2020', mobile: '0123456789', phone: '0123456789',email: 'support@shauryasoft.com',address: 'Delhi',fatherName: 'Deepak Joshi',fatherMobile: '9999999999',fatherEmail: 'Father@gmail.com',motherName: 'Mrs Joshi',motherMobile: '9897969594',motherEmail: 'Mother@gmail.com',bloodGroup: 'O+',house: 'Red house',religion: 'Hinduism',pickRoute: 'Station 1',dropRoute: 'Station 2'
      }, 
       {
        srNo: 6,admNo: 'D00158', admDate: '01/05/2024', studentName: 'Aarav Joshi', class: 'V-A', gender: 'Male', rollNo: 1, category: 'Staff Ward', birthDate: '05/02/2020', mobile: '0123456789', phone: '0123456789',email: 'support@shauryasoft.com',address: 'Delhi',fatherName: 'Deepak Joshi',fatherMobile: '9999999999',fatherEmail: 'Father@gmail.com',motherName: 'Mrs Joshi',motherMobile: '9897969594',motherEmail: 'Mother@gmail.com',bloodGroup: 'O+',house: 'Red house',religion: 'Hinduism',pickRoute: 'Station 1',dropRoute: 'Station 2'
      }
    // Add more student data objects as needed
  ];
  export default studentDataList;


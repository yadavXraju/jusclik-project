import logo from './logo.png';
export const SchoolData = {
  logo: logo, 
  name: 'THE WISDOM TREE SCHOOL',
};

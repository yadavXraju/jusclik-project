import User1 from 'assets/images/users/user-round.svg';

// static profile Details

export const ClassTeacherProfileDetails = {
  image: User1,
  name : 'Suraj Mishra',
  class : 'V A',
  subject : 'English',
  link : '/class-teacher/teacher-profile'
};

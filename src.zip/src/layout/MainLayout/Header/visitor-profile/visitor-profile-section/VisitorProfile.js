import User1 from 'assets/images/users/user-round.svg';

// static profile Details

export const VisitorProfileDetails = {
  image: User1,
  name : 'Vikash Poonia',
  class : '',
  subject : '',
  link : '/visitor/visitor-profile'
};

import User1 from 'assets/images/users/user-round.svg';

// static profile Details

export const studentProfileDetails = {
  image: User1,
  name : 'Abhishek Negi',
  class : 'V A',
  AdminNo :'(Adm No : D00158)',
};
